<?php

namespace Payments\Class\EU;

use Payments\Abstract\PaymentsEU;

class Alfa extends PaymentsEU
{
    public const API_KEY = 'zdxfajsdkhfoqkweghipofqvu';
}